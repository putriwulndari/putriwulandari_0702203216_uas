

<div class="row mt">
  <div class="col-lg-12">
     <div class="form-panel" style="width:50%;">
        <h4 class="mb"><span class='fa fa-briefcase'></span> Laporan Perbulan
        </h4>
 <div class="row">
 <form action="print_bulanan.php" target="_blank" method="post" id="form">
        <div class="col-lg-4 col-xs-4">
          <div class="form-group">
	
		  <input type="date" name="awal" class="form-control" placeholder="awal" required>
	 </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-4 col-xs-4">
          <div class="form-group">
		  <input type="date" name='akhir' class="form-control" placeholder="akhir" required>
	 </div>
        </div>
   <button class="btn btn-primary"><span class='fa fa-print'></span> Print</button>
    </form>
 </div>
    

	 </div>
  </div>
</div>