<?php 

$conn = mysqli_connect("localhost", "root", "", "web") or die(mysqli_connect_error());

?>